import React, { useState } from "react";
import Header from "./Header";
import InputForm from './InputForm';
//
function ImageGenerator() {
  return (
    <>
      <Header />
      <InputForm />
    </>
  );
};
//
export default ImageGenerator
