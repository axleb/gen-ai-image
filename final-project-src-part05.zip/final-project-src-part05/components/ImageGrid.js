import styles from "./../styles/ImageGenerator.module.css";
import ImageComponent from "./ImageComponent";
import {placeholderImages}  from "./../utils/placeholders"
//
function ImageGrid(){
  return (
    <div>
      <ImageComponent>

        
      </ImageComponent>
    </div>
  )
};
//
export default ImageGrid;
