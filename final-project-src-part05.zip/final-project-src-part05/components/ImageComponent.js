import { useState, useEffect } from "react";
import {generateImage}  from "./../utils/api";
import styles from "../styles/ImageComponent.module.css";
//
function ImageComponent( {placeholder, prompt} ) {
  const [image, setImage] = useState(placeholder);
  async function fetchImage(){
    try{
        const newImage = await generateImage(prompt);
        setImage(newImage);
    } catch(err){
        //
    } finally {

    };
  };

  //
  return (
  <div>
    <img src={image} alt="Generated" className={styles.image} />
  </div>
  )
};
//
export default ImageComponent;
