import React, { useState } from "react";
import ImageGrid from "./ImageGrid";
import Header from "./Header";
import InputForm from './InputForm';
//
function ImageGenerator() {
  return (
    <>
      <Header />
      <InputForm />
      <ImageGrid />
    </>
  );
};
//
export default ImageGenerator
