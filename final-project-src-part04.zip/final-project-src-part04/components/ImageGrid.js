import styles from "./../styles/ImageGenerator.module.css";
import ImageComponent from "./ImageComponent";
//
function ImageGrid(){
  return (
    <div></div>
  )
};
//
export default ImageGrid;
