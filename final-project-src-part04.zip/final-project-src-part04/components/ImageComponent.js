import { useState, useEffect } from "react";
import {generateImage}  from "./../utils/api";
import styles from "../styles/ImageComponent.module.css";
//
function ImageComponent() {
  return (
  <div>

  </div>
  )
};
//
export default ImageComponent;
