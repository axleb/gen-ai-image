import { useState } from "react";
import styles from "./../styles/ImageGenerator.module.css";
//
function InputForm() {
  return (
    <form>
      <input
        className={styles.input}
        type="text"
        value=""
        placeholder="Type your prompt here..."
      />
      <button className={styles.button} type="submit">
        Generate Image
      </button>
    </form>
  );
};
//
export default InputForm;
