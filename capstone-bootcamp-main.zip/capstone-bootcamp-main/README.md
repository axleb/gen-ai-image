
## India Bootcamp - Capstone project

### AI Image Generator

React-based AI Image Generator

Prerequisites for running locally - 

- Download and install Node.
    You can download it from the [Node.js official website](https://nodejs.org/).
- Make sure that you have Git installed on your system.
- Clone this repo

    ```
    git clone <url of this repo>
    ```

- cd into the project root folder
- Install dependencies with npm install
- Run the app with npm start

You should now have the app running at http://localhost:3000 in your browser!


