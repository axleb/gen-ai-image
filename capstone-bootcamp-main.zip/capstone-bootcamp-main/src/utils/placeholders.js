import placeholder1 from "../assets/image1.jpg";
import placeholder2 from "../assets/image2.jpg";
import placeholder3 from "../assets/image3.jpg";
import placeholder4 from "../assets/image4.jpg";

export const placeholderImages = [
  placeholder1,
  placeholder2,
  placeholder3,
  placeholder4,
];
