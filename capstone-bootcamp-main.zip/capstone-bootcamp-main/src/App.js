import React from "react";
import ImageGenerator from "./components/ImageGenerator";

function App() {
  return <ImageGenerator />;
}

export default App;
