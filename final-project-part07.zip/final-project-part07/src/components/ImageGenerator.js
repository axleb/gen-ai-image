import React, { useState } from "react";
import ImageGrid from "./ImageGrid";
import Header from "./Header";
import InputForm from './InputForm';
//
function ImageGenerator() {
  const [isGenerating, setIsGenerating] = useState(false);
  const [prompt, setPrompt] = useState("");
  const handleGenerateClick = (newPrompt) => {
    if (!newPrompt || isGenerating) return;
    setPrompt(newPrompt);
    setIsGenerating(true);
  };
  const handleGenerationComplete = () => {
    setIsGenerating(false);
    
  };

  return (
    <>
      <Header />
      <InputForm 
        onGenerate={handleGenerateClick}
        isGenerating={isGenerating}      
      />
      <ImageGrid 
        prompt={prompt}
        isGenerating={isGenerating}
        onGenerationComplete={handleGenerationComplete}
      />
    </>
  );
};
//
export default ImageGenerator
