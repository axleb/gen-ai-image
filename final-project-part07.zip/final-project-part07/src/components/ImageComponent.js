import { useState, useEffect } from "react";
import {generateImage}  from "./../utils/api";
import styles from "../styles/ImageComponent.module.css";
//
function ImageComponent( {placeholder, prompt, isGenerating, onGenerationComplete} ) {
  const [image, setImage] = useState(placeholder);
  const [isLoading, setIsLoading] = useState(false);
  const [error, setError] = useState(null);  

  async function fetchImage(){
    try{
        const newImage = await generateImage(prompt);
        setImage(newImage);
    } catch(err){
      setError("Error in generating image: "+ err);
    } finally {
      setIsLoading(false);
      onGenerationComplete();
    };
  };
  //
  useEffect(() => {
    if (isGenerating) {
      fetchImage();
    }
  }, [isGenerating, fetchImage] );
  //
  return (
  <div>
    <img src={image} alt="Generated" className={styles.image} />
  </div>
  )
};
//
export default ImageComponent;
