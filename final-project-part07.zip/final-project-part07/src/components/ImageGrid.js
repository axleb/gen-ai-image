import styles from "./../styles/ImageGenerator.module.css";
import ImageComponent from "./ImageComponent";
import {placeholderImages}  from "./../utils/placeholders"
//
function ImageGrid({ prompt, isGenerating, onGenerationComplete } ){
  return (
    <div className={styles.images}>
      <ImageComponent
        placeholder={placeholderImages[0]}
        prompt={prompt}
        isGenerating={isGenerating}
        onGenerationComplete={onGenerationComplete}
      >
      </ImageComponent>
    </div>
  )
};
//
export default ImageGrid;
