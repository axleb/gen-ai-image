import React from "react";
import styles from "./../styles/ImageGenerator.module.css";
const Header = () => <
  h1 className={styles.heading}>
    AI Image Generator
  </h1>;
//
export default Header;

