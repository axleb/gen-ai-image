import React, { useState } from "react";
import ImageGrid from "./ImageGrid";
import Header from "./Header";
import InputForm from './InputForm';
//
function ImageGenerator() {
  const [isGenerating, setIsGenerating] = useState(false);
  const handleGenerateClick = (newPrompt) => {
  };
  return (
    <>
      <Header />
      <InputForm 
        onGenerate={handleGenerateClick}
        isGenerating={isGenerating}      
      />
      <ImageGrid />
    </>
  );
};
//
export default ImageGenerator
