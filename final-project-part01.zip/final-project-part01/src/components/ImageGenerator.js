import React, { useState } from "react";
import Header from "./Header";
//
function ImageGenerator() {
  return (
    <>
      <Header />
    </>
  );
};
//
export default ImageGenerator
