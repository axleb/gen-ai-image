import ImageGenerator from "./components/ImageGenerator";
//
function App() {
  return (
    <div>
      <ImageGenerator />
    </div>
  );
}
//
export default App;
